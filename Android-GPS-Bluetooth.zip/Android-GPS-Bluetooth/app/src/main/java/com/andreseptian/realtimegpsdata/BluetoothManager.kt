package com.andreseptian.realtimegpsdata

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import java.util.*

class BluetoothManager(private val context: Context) {

    private val bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter
    private val bluetoothLeScanner = bluetoothAdapter?.bluetoothLeScanner

    private var gatt: BluetoothGatt? = null
    private var isConnected = false
    private var onDataReceived: ((String) -> Unit)? = null

    // UUID из ESP32 кода
    private val serviceUUID = UUID.fromString("7a4b8c2d-9e1f-4a3d-b5c6-7d8e9f0a1b2d")

    // Характеристики для чтения/записи
    private val settingsUUID = UUID.fromString("9d37a346-63d3-4df6-8eee-f0242949f59f")
    private val navUUID = UUID.fromString("0b11deef-1563-447f-aece-d3dfeb1c1f20")
    private val navIconUUID = UUID.fromString("d4d8fcca-16b2-4b8e-8ed5-90137c44a8ad")
    private val gpsSpeedUUID = UUID.fromString("98b6073a-5cf3-4e73-b6d3-f8e05fa018a9")
    private val gpsPosUUID = UUID.fromString("7a4b8c2d-9e1f-4a3d-b5c6-7d8e9f0a1b2c")
    private val modeUUID = UUID.fromString("00000004-0000-0000-0000-000000000000")

    // Для отправки GPS данных используем характеристику GPS_SPEED
    private val characteristicUUID = gpsPosUUID

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val deviceName = device.name ?: ""

            // Ищем устройство с именем CatDrive (как в ESP32 коде)
            if (deviceName.contains("CatDrive", ignoreCase = true)) {
                Log.d("BluetoothManager", "Found CatDrive: $deviceName - ${device.address}")
                onDeviceFound?.invoke(device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e("BluetoothManager", "Scan failed with error: $errorCode")
        }
    }

    var onDeviceFound: ((BluetoothDevice) -> Unit)? = null

    @SuppressLint("MissingPermission")
    fun scanDevices(onDeviceFound: (BluetoothDevice) -> Unit) {
        this.onDeviceFound = onDeviceFound

        if (!hasBluetoothPermission()) {
            Log.e("BluetoothManager", "Bluetooth permissions not granted")
            return
        }

        bluetoothLeScanner?.stopScan(scanCallback)

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()

        val filters = listOf(
            ScanFilter.Builder()
                // Можно добавить фильтр по сервису
                // .setServiceUuid(ParcelUuid(serviceUUID))
                .build()
        )

        try {
            bluetoothLeScanner?.startScan(filters, settings, scanCallback)

            Handler(Looper.getMainLooper()).postDelayed({
                stopScan()
            }, 10000)
        } catch (e: SecurityException) {
            Log.e("BluetoothManager", "Security exception: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        try {
            bluetoothLeScanner?.stopScan(scanCallback)
        } catch (e: SecurityException) {
            Log.e("BluetoothManager", "Security exception: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(
        device: BluetoothDevice,
        retryCount: Int = 3,
        onConnectionSuccess: () -> Unit,
        onConnectionFailed: (Exception) -> Unit,
        onDataReceived: (String) -> Unit
    ) {
        this.onDataReceived = onDataReceived

        if (!hasBluetoothPermission()) {
            onConnectionFailed(Exception("Bluetooth permissions not granted"))
            return
        }

        var attempts = 0

        fun attemptConnection() {
            attempts++
            try {
                gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
                    override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                        when (newState) {
                            BluetoothProfile.STATE_CONNECTED -> {
                                Log.d("BluetoothManager", "Connected to GATT server")
                                gatt.discoverServices()
                            }
                            BluetoothProfile.STATE_DISCONNECTED -> {
                                if (attempts < retryCount) {
                                    Log.d("BluetoothManager", "Connection attempt $attempts failed, retrying...")
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        attemptConnection()
                                    }, 1000)
                                } else {
                                    isConnected = false
                                    onConnectionFailed(Exception("Connection failed after $retryCount attempts"))
                                }
                            }
                        }
                    }

                    override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                        if (status == BluetoothGatt.GATT_SUCCESS) {
                            val service = gatt.getService(serviceUUID)
                            if (service != null) {
                                Log.d("BluetoothManager", "Service found: $serviceUUID")

                                // Ищем характеристику для GPS данных
                                val characteristic = service.getCharacteristic(characteristicUUID)
                                if (characteristic != null) {
                                    // Включаем уведомления если нужно читать данные с ESP32
                                    val success = gatt.setCharacteristicNotification(characteristic, true)
                                    if (success) {
                                        // Для уведомлений нужен дескриптор CCCD
                                        val descriptor = characteristic.getDescriptor(
                                            UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
                                        )
                                        if (descriptor != null) {
                                            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                            gatt.writeDescriptor(descriptor)
                                        }
                                    }

                                    isConnected = true
                                    onConnectionSuccess()
                                } else {
                                    if (attempts < retryCount) {
                                        Handler(Looper.getMainLooper()).postDelayed({
                                            attemptConnection()
                                        }, 1000)
                                    } else {
                                        onConnectionFailed(Exception("GPS characteristic not found"))
                                    }
                                }
                            } else {
                                if (attempts < retryCount) {
                                    Handler(Looper.getMainLooper()).postDelayed({
                                        attemptConnection()
                                    }, 1000)
                                } else {
                                    onConnectionFailed(Exception("Service not found: $serviceUUID"))
                                }
                            }
                        } else {
                            if (attempts < retryCount) {
                                Handler(Looper.getMainLooper()).postDelayed({
                                    attemptConnection()
                                }, 1000)
                            } else {
                                onConnectionFailed(Exception("Services discovery failed"))
                            }
                        }
                    }

                    override fun onCharacteristicChanged(
                        gatt: BluetoothGatt,
                        characteristic: BluetoothGattCharacteristic
                    ) {
                        val data = String(characteristic.value)
                        Log.d("BluetoothManager", "Received: $data")
                        onDataReceived(data)
                    }
                })
            } catch (e: SecurityException) {
                Log.e("BluetoothManager", "Security exception: ${e.message}")
                if (attempts < retryCount) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        attemptConnection()
                    }, 1000)
                } else {
                    onConnectionFailed(e)
                }
            }
        }

        attemptConnection()
    }

    @SuppressLint("MissingPermission")
    fun sendData(data: String) {
        if (!isConnected || gatt == null) return

        try {
            val service = gatt?.getService(serviceUUID) ?: return
            val characteristic = service.getCharacteristic(characteristicUUID) ?: return

            characteristic.value = data.toByteArray()
            characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

            gatt?.writeCharacteristic(characteristic)
            Log.d("BluetoothManager", "Sent: $data")
        } catch (e: Exception) {
            Log.e("BluetoothManager", "Failed to send data: ${e.message}")
        }
    }

    fun closeConnection() {
        try {
            gatt?.disconnect()
            gatt?.close()
            gatt = null
            isConnected = false
        } catch (e: Exception) {
            Log.e("BluetoothManager", "Error closing connection: ${e.message}")
        }
    }

    private fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun getDeviceByAddress(address: String): BluetoothDevice? {
        return try {
            bluetoothAdapter?.getRemoteDevice(address)
        } catch (e: Exception) {
            Log.e("BluetoothManager", "Failed to get device: ${e.message}")
            null
        }
    }
}