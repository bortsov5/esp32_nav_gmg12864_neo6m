package com.andreseptian.realtimegpsdata

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class BluetoothForegroundService : Service() {

    private lateinit var bluetoothManager: BluetoothManager
    private lateinit var locationManager: LocationManager

    companion object {
        const val NOTIFICATION_ID = 1
        const val CHANNEL_ID = "bluetooth_service_channel"
        const val EXTRA_DEVICE_ADDRESS = "EXTRA_DEVICE_ADDRESS"
    }

    override fun onCreate() {
        super.onCreate()
        bluetoothManager = BluetoothManager(this)
        locationManager = LocationManager(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Указываем тип foreground service для Android 14+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                createNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else {
            startForeground(NOTIFICATION_ID, createNotification())
        }

        intent?.let {
            val deviceAddress = it.getStringExtra(EXTRA_DEVICE_ADDRESS)
            deviceAddress?.let { address ->
                val device = bluetoothManager.getDeviceByAddress(address)
                device?.let { bluetoothDevice ->
                    connectAndStartGps(bluetoothDevice)
                }
            }
        }

        return START_STICKY
    }

    private fun connectAndStartGps(device: BluetoothDevice) {
        updateNotification("Подключение к ${device.name ?: "устройству"}...")

        bluetoothManager.connectToDevice(
            device,
            retryCount = 3,
            onConnectionSuccess = {
                updateNotification("Подключено. Запуск GPS...")
                locationManager.startLocationUpdates { latitude, longitude, speed ->
                    val data = "$latitude,$longitude,$speed"
                    bluetoothManager.sendData(data)
                    updateNotification("📍 %.6f, %.6f | %.1f м/с".format(latitude, longitude, speed))
                }
            },
            onConnectionFailed = { exception ->
                updateNotification("Ошибка: ${exception.message}")
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    connectAndStartGps(device)
                }, 10000)
            },
            onDataReceived = { data ->
                android.util.Log.d("ForegroundService", "Received: $data")
            }
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bluetooth GPS Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Отправка GPS данных через Bluetooth"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Bluetooth GPS")
        .setContentText("Отправка данных...")
        .setSmallIcon(android.R.drawable.ic_menu_mapmode)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    private fun updateNotification(text: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bluetooth GPS Активен")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mapmode)
            .build()
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        locationManager.stopLocationUpdates()
        bluetoothManager.closeConnection()
    }
}